<?php

//=======================================================
// Set Cookie Login to FALSE by Default
//=======================================================
$GLOBALS['cookie_login'] = false;

//=======================================================
// Login from "Remember Me" Cookie?
//=======================================================
if (!empty($_COOKIE['remember-me'])) {
	$GLOBALS['mod'] = 'login';
	$_POST['user'] = $_COOKIE['remember-me'];
	$GLOBALS['cookie_login'] = true;
}

//=======================================================
// Set Authentication Data Source to "Custom"
//=======================================================
$config_arr['auth_data_source'] = "custom";

//=======================================================
// Authentication Functions
//=======================================================
if (!function_exists('custom_login')) {

	//=======================================================
	// Custom Login
	//=======================================================
	function custom_login()
	{
		$user_info = false;
		$data_source = 'main';

		//---------------------------------------------------------
		// Cookie Login
		//---------------------------------------------------------
		if ($GLOBALS['cookie_login']) {
			$strsql = '
				select 
					users.*,
					users.id as user_id,
					concat(persons.first_name, " ", persons.last_name) as full_name,
					persons.*
				from 
					users,
					persons 
				where 
					users.remember_me = ? 
					and persons.id = users.person_id
					and persons.active = 1
					and persons.deleted = 0
			';
			$user_info = qdb_first_row($data_source, $strsql, array('s', $_POST['user']));
			
		}
		//---------------------------------------------------------
		// POST User ID / Password Login
		//---------------------------------------------------------
		else {
			if (!isset($_POST['user']) || !isset($_POST['pass'])) {
				trigger_error('Login parameters not found.');
				return false;
			}
			$user = $_POST['user'];
			$pass = $_POST['pass'];

			$strsql = '
				select 
					users.*,
					users.id as user_id,
					concat(persons.first_name, " ", persons.last_name) as full_name,
					persons.*
				from 
					users,
					persons 
				where 
					users.userid = ? 
					and users.password = sha1(?)
					and persons.id = users.person_id
					and persons.active = 1
					and persons.deleted = 0
			';
			$user_info = qdb_first_row($data_source, $strsql, array('ss', $user, $pass));
		}

		//---------------------------------------------------------
		// Successful Login
		//---------------------------------------------------------
		if ($user_info) {

			//---------------------------------------------------------
			// Save Cookie for "Remember Me" Login
			//---------------------------------------------------------
			if (!empty($_POST['remember_me']) || $GLOBALS['cookie_login']) {
				$version = file_get_contents(__DIR__ . '/../VERSION');
				$value = md5($version . $user_info['userid'] . $_SERVER['REMOTE_ADDR']);
				setcookie("remember-me", $value, time()+432000, "/", $_SERVER['HTTP_HOST'], 0); // 259200
				$strsql = 'update users set remember_me = ? where id = ?';
				qdb_exec($data_source, $strsql, array('si', $value, $user_info['id']));
			}

			$_SESSION['person_id'] = $user_info['person_id'];
			$_SESSION['user_id'] = $user_info['user_id'];
			$_SESSION['password'] = $user_info['password'];
			$_SESSION['full_name'] = $user_info['first_name'] . ' ' . $user_info['last_name'];
			$_SESSION['user_full_name'] = $_SESSION['full_name'];
			$_SESSION['nickname'] = $user_info['nickname'];
			$_SESSION['is_admin'] = $user_info['admin'];
			$_SESSION['is_developer'] = $user_info['developer'];
			$_SESSION['change_password'] = $user_info['change_password'];
			return $user_info['userid'];
		}

		return false;
	}


	//=======================================================
	// Failed Login Function
	//=======================================================
	function failed_login()
	{
		if ($GLOBALS['cookie_login']) {
			setcookie("remember-me", '', time()-3600, "/", $_SERVER['HTTP_HOST'], 0);
			return 'login';			
		}

		return 1;
	}
}

?>