<?php

//=======================================================
// Set Authentication Data Source to "Custom"
//=======================================================
$config_arr['auth_data_source'] = "custom";

//=======================================================
// Authentication Functions
//=======================================================
if (!function_exists('custom_login')) {

	//=======================================================
	// Custom Login
	//=======================================================
	function custom_login()
	{
		$user_info = false;
		$data_source = 'main';

		//---------------------------------------------------------
		// Simplified Test Login Scenario
		//---------------------------------------------------------
		if ($_POST['user'] == 'test' && $_POST['pass'] == '123') {
			$user_info = array(
				'userid' => $_POST['user'],
				'first_name' => 'Test',
				'last_name' => 'User',
				'password' => sha1($_POST['pass']),
				'admin' => 0,
				'change_password' => 0
			);
		}

		//---------------------------------------------------------
		// Successful Login
		//---------------------------------------------------------
		if ($user_info) {

			$_SESSION['password'] = $user_info['password'];
			$_SESSION['full_name'] = $user_info['first_name'] . ' ' . $user_info['last_name'];
			$_SESSION['user_full_name'] = $_SESSION['full_name'];
			$_SESSION['is_admin'] = $user_info['admin'];
			$_SESSION['change_password'] = $user_info['change_password'];
			return $user_info['userid'];
		}

		return false;
	}


}

?>