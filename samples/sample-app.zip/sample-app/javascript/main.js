//****************************************************************
//****************************************************************
// JQuery Initializer
//****************************************************************
//****************************************************************
$(document).ready(function()
{
	app_env = $('body').attr('app_env');
	segment_1 = $('body').attr('segment_1');
	segment_2 = $('body').attr('segment_2');
	segment_3 = $('body').attr('segment_3');
	segment_4 = $('body').attr('segment_4');
	segment_5 = $('body').attr('segment_5');
	loading_img = '<img src="/img/ajax-loader.gif" />';

	//****************************************************
	// Add "form-control" class to appropriate inputs
	//****************************************************
	$('input[type="text"], input[type="password"], select, textarea').addClass('form-control');
 
});

//****************************************************************
//****************************************************************
// Functions
//****************************************************************
//****************************************************************

//****************************************************
// Newline to Break Tag Function
//****************************************************
function nl2br(str, is_xhtml)
{
    var breakTag = (is_xhtml || typeof is_xhtml === 'undefined') ? '<br />' : '<br>';
    return (str + '').replace(/([^>\r\n]?)(\r\n|\n\r|\r|\n)/g, '$1' + breakTag + '$2');
}
