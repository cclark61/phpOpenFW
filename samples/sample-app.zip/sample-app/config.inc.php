<?php
//***************************************************************************
//***************************************************************************
// Application Configuration
//***************************************************************************
//***************************************************************************

//=======================================================
// Path to Framework Directory
//=======================================================
$config_arr["frame_path"] = "/var/www/html/Library/php/phpOpenFW1/framework";

//=======================================================
// XML Nav Format (numeric, rewrite, long_url)
//=======================================================
$config_arr["nav_xml_format"] = "rewrite";
//$config_arr["nav_xml_format"] = "long_url";
//$config_arr["nav_xml_format"] = "numeric";

//=======================================================
// Modules Directory
//=======================================================
$config_arr['modules_dir'] = 'modules';

//=======================================================
// Settings
//=======================================================
$config_arr["theme"] = "default";
$config_arr["creator"] = "Your Company";

//=======================================================
// Developers (Space separated User IDs)
//=======================================================
$config_arr["developers"] = "";

//=======================================================
// Version
//=======================================================
$config_arr['version'] = file_get_contents('VERSION');

//=======================================================
// Reset HTML Path
//=======================================================
$config_arr['html_path'] = '';

//=======================================================
// Custom Login
//=======================================================
$custom_login = __DIR__ . '/config/custom_login.inc.php';
if (file_exists($custom_login)) { include($custom_login); }

//=======================================================
// Default Data Source
//=======================================================
$config_arr['default_data_source'] = 'main';

//***************************************************************************
//***************************************************************************
// Authentication
// Login Settings
//***************************************************************************
//***************************************************************************

//=======================================================
// Data Source to use for authentication
//=======================================================
//$config_arr["auth_data_source"] = "main";
$config_arr['auth_data_source'] = 'custom';

//=======================================================
// Database Authentication Parameters
//=======================================================
//$config_arr["auth_user_table"] = "users";
//$config_arr["auth_user_field"] = "userid";
//$config_arr["auth_pass_field"] = "password";
//$config_arr["auth_fname_field"] = "first_name";
//$config_arr["auth_lname_field"] = "last_name";

//=======================================================
// Password Security
// ** Options: [ clear, md5, sha1, sha256 ]
//=======================================================
$config_arr["auth_pass_security"] = "sha1";

//=======================================================
// Set Mode / Environment
//=======================================================
$server_name = $_SERVER['SERVER_NAME'];
$dev_match = stristr($server_name, '.dev.');
$test_match = stristr($server_name, '.test.');
if ($dev_match) { $config_arr['mode'] = 'dev'; }
else if ($test_match) { $config_arr['mode'] = 'test'; }
else { $config_arr['mode'] = 'live'; }
if ($dev_match) { $config_arr['ENV'] = 'dev'; }
else { $config_arr['ENV'] = 'prod'; }

//***************************************************************************
//***************************************************************************
// Application Specific Configuration
//***************************************************************************
//***************************************************************************
$config_arr['app_code'] = 'app';
include('config/app.php');

?>