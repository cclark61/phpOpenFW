<?php
//=========================================================================
// Pre-message execution include file
//=========================================================================

//**************************************************
// Set Current Date
//**************************************************
$this->add_xml("current_date", date('l, M j, Y'));
$this->add_xml("current_year", date('Y'));

//**************************************************************
// Site Settings
//**************************************************************
if (isset($_SESSION['login_title'])) { $this->add_xml("login_title", xml_escape($_SESSION['login_title'])); }
if (isset($_SESSION['site_title'])) { $this->add_xml("site_title", xml_escape($_SESSION['site_title'])); }
if (isset($_SESSION['site_logo'])) { $this->add_xml("site_logo", xml_escape($_SESSION['site_logo'])); }
if (isset($_SESSION['site_logo_icon'])) { $this->add_xml("site_logo_icon", xml_escape($_SESSION['site_logo_icon'])); }
if (isset($_SESSION['fav_icon'])) { $this->add_xml("fav_icon", xml_escape($_SESSION['fav_icon'])); }
if (isset($_SESSION['touch_icon'])) { $this->add_xml("touch_icon", xml_escape($_SESSION['touch_icon'])); }
if (isset($_SESSION['creator'])) { $this->add_xml("creator", xml_escape($_SESSION['creator'])); }
if (isset($_SESSION['app_url'])) { $this->add_xml("app_url", xml_escape($_SESSION['app_url'])); }

//**************************************************************************
// Version
//**************************************************************************
$_SESSION['version'] = file_get_contents('VERSION');
$this->add_xml("version", xml_escape($_SESSION["version"]));

?>