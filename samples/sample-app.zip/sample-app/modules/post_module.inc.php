<?php
//=========================================================================
//=========================================================================
// Post-module execution include file
//=========================================================================
//=========================================================================

//**************************************************************
// Is Admin?
// Current Module
// User Full Name
//**************************************************************
if (defined('IS_ADMIN')) {
	$this->add_xml("is_admin", (int)IS_ADMIN);
}
if (isset($GLOBALS['current_module'])) {
	$this->add_xml("current_module", $GLOBALS['current_module']);
}
if (isset($_SESSION['user_full_name'])) {
	$this->add_xml("user_full_name", xml_escape($_SESSION['user_full_name']));
}

//**************************************************************
// Environment
//**************************************************************
if (isset($_SESSION['ENV'])) { $this->add_xml("app_env", xml_escape($_SESSION['ENV'])); }

//**************************************************************
// Segments
//**************************************************************
if (isset($segment_1)) { $this->add_xml("segment_1", xml_escape($segment_1)); }
if (isset($segment_2)) { $this->add_xml("segment_2", xml_escape($segment_2)); }
if (isset($segment_3)) { $this->add_xml("segment_3", xml_escape($segment_3)); }
if (isset($segment_4)) { $this->add_xml("segment_4", xml_escape($segment_4)); }
if (isset($segment_5)) { $this->add_xml("segment_5", xml_escape($segment_5)); }

//**************************************************************
// Theme
//**************************************************************
$this->add_xml("theme", $this->theme);
$this->add_xml("theme_path", "{$this->html_path}/themes/{$this->theme}");

//**************************************************************
// Site Settings
//**************************************************************
if (isset($site_title)) { $this->add_xml("site_title", xml_escape($site_title)); }
else if (isset($_SESSION['site_title'])) { $this->add_xml("site_title", xml_escape($_SESSION['site_title'])); }
if (isset($_SESSION['site_logo'])) { $this->add_xml("site_logo", xml_escape($_SESSION['site_logo'])); }
if (isset($_SESSION['site_logo_icon'])) { $this->add_xml("site_logo_icon", xml_escape($_SESSION['site_logo_icon'])); }
if (isset($_SESSION['touch_icon'])) { $this->add_xml("touch_icon", xml_escape($_SESSION['touch_icon'])); }
if (isset($_SESSION['fav_icon'])) { $this->add_xml("fav_icon", xml_escape($_SESSION['fav_icon'])); }
if (isset($_SESSION['creator'])) { $this->add_xml("creator", xml_escape($_SESSION['creator'])); }
if (isset($_SESSION['app_url'])) { $this->add_xml("app_url", xml_escape($_SESSION['app_url'])); }

//**************************************************************
// Module Title
//**************************************************************
if (empty($mod_title)) {
	$mod_title = (!empty($GLOBALS['mod_title'])) ? ($GLOBALS['mod_title']) : ("???");
}
$this->add_xml("mod_title", xml_escape($mod_title));
if (empty($mod_title1)) { $mod_title1 = 'Menu'; }
$this->add_xml("mod_title1", xml_escape($mod_title1));
if (!empty($mod_title2)) { $this->add_xml("mod_title2", xml_escape($mod_title2)); }
if (!empty($mod_title3)) { $this->add_xml("mod_title3", xml_escape($mod_title3)); }

//**************************************************************
// Sub Title / Back Link
//**************************************************************
if (isset($sub_title)) { $this->add_xml("sub_title", xml_escape($sub_title)); }
if (isset($back_link)) { $this->add_xml("back_link", xml_escape($back_link)); }

//**************************************************************
// Module Image
//**************************************************************
if (isset($mod_image)) { $this->add_xml("mod_image", xml_escape($mod_image)); }

//**************************************************************
// Module Images / Icon Classes
//**************************************************************
if (isset($mod_icon_class)) { $this->add_xml("mod_icon_class", xml_escape($mod_icon_class)); }
if (isset($mod_icon_class1)) { $this->add_xml("mod_icon_class1", xml_escape($mod_icon_class1)); }
if (isset($mod_icon_class2)) { $this->add_xml("mod_icon_class2", xml_escape($mod_icon_class2)); }
if (isset($mod_icon_class3)) { $this->add_xml("mod_icon_class3", xml_escape($mod_icon_class3)); }

//**************************************************************
// Links
//**************************************************************
if (isset($top_mod_links) && is_array($top_mod_links) && count($top_mod_links) > 0) { $this->add_xml("top_mod_links", $top_mod_links); }

//**************************************************************
// Breadcrumbs
//**************************************************************
if (isset($breadcrumbs) && is_array($breadcrumbs) && count($breadcrumbs) > 0) { $this->add_xml("breadcrumbs", $breadcrumbs); }

//**************************************************************
// Convert Message strings into arrays
//**************************************************************
if (isset($error_message) && !is_array($error_message)) { $error_message = array($error_message); }
if (isset($warn_message) && !is_array($warn_message)) { $warn_message = array($warn_message); }
if (isset($action_message) && !is_array($action_message)) { $action_message = array($action_message); }
if (isset($gen_message) && !is_array($gen_message)) { $gen_message = array($gen_message); }

//**************************************************************
// Messages
//**************************************************************
$message_types = array(
	'error_message',
	'warn_message',
	'action_message',
	'gen_message',
	'page_message',
	'bottom_message',
	'timer_message'
);

foreach ($message_types as $msg_type) {
	if (!empty($$msg_type) || !empty($_SESSION[$msg_type])) {
		$formatted_messages = false;
		if (!empty($$msg_type) && !empty($_SESSION[$msg_type])) {
			$formatted_messages = format_page_messages($$msg_type, $_SESSION[$msg_type]);
			unset($_SESSION[$msg_type]);
		}
		else if (!empty($$msg_type)) {
			$formatted_messages = format_page_messages($$msg_type);
		}
		else if (!empty($_SESSION[$msg_type])) {
			$formatted_messages = format_page_messages($_SESSION[$msg_type]);
			unset($_SESSION[$msg_type]);
		}
		if ($formatted_messages) {
			$this->add_xml($msg_type, array2xml('messages', $formatted_messages));
		}
	}
}

//**************************************************************
//**************************************************************
// Format Page Messages function
//**************************************************************
//**************************************************************
function format_page_messages()
{
	$messages = array();
	$args = func_get_args();
	foreach ($args as $arg) {
		if (is_array($arg) && count($arg) > 0) {
			foreach ($arg as $key => $arg_msg) {
				$messages[] = xml_escape($arg_msg);
			}
		}
		else if ((string)$arg != '') {
			$messages[] = xml_escape($arg);
		}
	}

	return $messages;
}

?>