<?php

$mod_title = "Home";
$mod_icon_class = 'fa fa-home';

?>