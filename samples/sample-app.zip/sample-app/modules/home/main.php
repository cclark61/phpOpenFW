<?php

print "Hello World!";

?>