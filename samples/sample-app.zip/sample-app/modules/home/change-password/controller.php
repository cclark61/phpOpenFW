<?php

$mod_title = "Change Password";

switch ($segment_2) {
        
	default:
		include("main.php");
		break;
}

?>