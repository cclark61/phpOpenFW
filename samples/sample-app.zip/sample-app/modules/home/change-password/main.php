<?php

//============================================================================
// Update?
//============================================================================
if (isset($_POST["update_pass"])) {

	// Check for form key
	$do_trans = check_and_clear_form_key($this, "form_key", $form_key);

	if ($do_trans) {
		if (get_saveable_password($curr_pass) == $_SESSION["password"]) {
			if ($new_pass1 != '' && strlen($new_pass1) > 5 && $new_pass1 == $new_pass2) {
				$enc_new_pass = get_saveable_password($new_pass1);
				$strsql = "
					update users set 
						password = ?, 
						update_person_id = ?, 
						update_dttm = NOW(), 
						change_password = 0 
					where 
						userid = ?
				";
				qdb_exec('', $strsql, array('sis', $enc_new_pass, $_SESSION['person_id'], $_SESSION['userid']));
				$_SESSION["password"] = $enc_new_pass;
				$_SESSION['change_password'] = 0;
				add_action_message("Your password has been changed.");
				redirect('/');
			}
			else if ($new_pass1 == $new_pass2 && strlen($new_pass1) < 6) {
				add_warn_message("New password must be at least 6 characters long. Please try again.");
				include("form.php");				
			}
			else {
				add_warn_message("New passwords do not match. Please try again.");
				include("form.php");
			}
		}
		else {
			add_warn_message("Incorrect current password. Please try again.");
			include("form.php");
		}
	}
	else {
		redirect('/');
	}
}
else {
	include("form.php");
}

?>