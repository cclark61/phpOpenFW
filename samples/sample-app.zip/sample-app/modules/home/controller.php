<?php

//============================================================
// Include Local Functions / Variables
//============================================================
$local_func = __DIR__ . '/local.func.php';
if (file_exists($local_func)) { include($local_func); }
$local_var = __DIR__ . '/local.var.php';
if (file_exists($local_var)) { include($local_var); }

//============================================================
// Load Plugins
//============================================================
if (!empty($plugins)) { foreach ($plugins as $plugin) { load_plugin($plugin); } }
if (!empty($plugins2)) { foreach ($plugins2 as $plugin) { load_module_plugin($plugin); } }

//============================================================
// Flow Control
//============================================================
switch ($this->action) {

	default:
		include("main.php");
		break;
}

?>