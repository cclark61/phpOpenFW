<?php

//==============================================================
// Flow Control
//==============================================================
switch ($segment_1) {

	case 'change-password':
		include(__DIR__ . '/home/change-password/controller.php');
		break;

	default:
		include('home/controller.php');
		break;
}

?>