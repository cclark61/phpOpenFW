<?php
//=========================================================================
//=========================================================================
// Pre-module execution include file
//=========================================================================
//=========================================================================

load_plugin("ssv");
load_plugin("app_common");
spl_autoload_register('load_plugin');

//**********************************************************
// New Version? Force Re-login
//**********************************************************
if (!isset($_SESSION['version'])) {
	redirect('/?mod=logout');
}
if ($_SESSION['version'] != file_get_contents($this->file_path . '/VERSION')) {
	redirect('/?mod=logout');
}

//**********************************************************
// Add-in CSS
//**********************************************************
$this->add_css_file('//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css');
$this->add_css_file('//maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css');
$this->add_css_file("{$this->html_path}/themes/{$this->theme}/app.css");

//**********************************************************
// Add-in Javascript
//**********************************************************
$this->add_js_file('//code.jquery.com/jquery-1.11.1.min.js');
$this->add_js_file('//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js');
$this->add_js_file('/javascript/stay_standalone.js');
$this->add_js_file('main.js');

//**********************************************************
// Reset Action (if necessary)
//**********************************************************
if (empty($_GET['action']) && empty($_POST['action']) && isset($this->mod_params[0])) {
	$this->action = $this->mod_params[0];
	$action = $this->action;
}

//**********************************************************
// Set Current Date
//**********************************************************
$this->add_xml("current_date", date('l, M j, Y'));
$this->add_xml("current_year", date('Y'));

//**********************************************************
// Version
//**********************************************************
$this->add_xml('version', xml_escape($_SESSION['version']));

//**********************************************************
// Set Current Date
//**********************************************************
$this->add_xml("current_date", date('l, M j, Y'));
$this->add_xml("current_year", date('Y'));

//**********************************************************
// Message Arrays
//**********************************************************
$error_message = array();
$warn_message = array();
$action_message = array();
$gen_message = array();

//**********************************************************
// Nav Arrays
//**********************************************************
$top_mod_links = array();
$breadcrumbs = array();

//**********************************************************
// Module Icon
//**********************************************************
global $mod_icon_class;

//**********************************************************
// Images
//**********************************************************
$add_image = icon('fa fa-plus');
$edit_image = icon('fa fa-pencil');
$open_image = icon('fa fa-folder-open');
$delete_image = icon('fa fa-times');
$view_image = icon('fa fa-search');
$print_image = icon('fa fa-print');
$check_image = icon('fa fa-check');
$filter_image = icon('fa fa-filter');
$action_image = icon('fa fa-thumbs-up');
$cat_image = icon('fa fa-list-ul');
$arrowr_image = icon('fa fa-chevron-circle-right');
$arrowl_image = icon('fa fa-chevron-circle-left');

//**********************************************************
// Set Action / Next action
//**********************************************************
$next_action = array(
	"add" => "insert", 
	"edit" => "update", 
	"confirm_delete" => "delete",
	'view' => ''
);

//**********************************************************
// Module URLs
//**********************************************************
$page_url = $this->page_url;
if ($_SESSION['nav_xml_format'] == 'long_url') { $page_url .= 'index.php/'; }
$GLOBALS['mod_base_url'] = $page_url;
$GLOBALS['mod_base_url2'] = $page_url;
$mod_base_url =& $GLOBALS['mod_base_url'];
$mod_base_url2 =& $GLOBALS['mod_base_url2'];

//**********************************************************
// Base URL
//**********************************************************
$this->add_xml('base_url', xml_escape($page_url));

//**********************************************************
// Set Segments
//**********************************************************
$max_segments = 5;
$segments = array();
$segments2 = array();
$current_path = '';
$GLOBALS['current_module'] = '';

for ($i=0; $i <= $max_segments; $i++) {
	$key = $i+1;
	$segments[$key] = (isset($this->mod_params[$i])) ? ($this->mod_params[$i]) : (false);
	if ($segments[$key] !== false) {
		$segments2[$key] = $segments[$key];
	}
	$segment_var = "segment_{$key}";
	$$segment_var = $segments[$key];
	define('SEGMENT_' . $key, $segments[$key]);
	$this->add_xml('segment_' . $key, $segments[$key]);
	
	if (!empty($segments[$key])) {
		$current_path .= '/' . $segments[$key];
	}
}

$GLOBALS['segments'] = $segments;
$GLOBALS['segments2'] = $segments2;

//**********************************************************
// Force Change Password?
//**********************************************************
if (!empty($_SESSION['change_password']) && $segment_1 != 'change-password') {
	redirect("/change-password/");
}

//**********************************************************
// Modules Common Directory
//**********************************************************
$mod_common_dir = __DIR__ . '/common';
define('MOD_COMMON_DIR', $mod_common_dir);
set_include_path(get_include_path() . PATH_SEPARATOR . $mod_common_dir);

//**********************************************************
// Constants
//**********************************************************
define('DATA_SRC', $_SESSION['default_data_source']);
define('BASE_URL', $page_url);
define('DEFAULT_TIMESTAMP', 'n/j/Y g:i a');
define('EXTRACT_DATETIME_FORMAT', 'm/d/Y H:i');

//**********************************************************
// Yes / No Array
//**********************************************************
$arr_yes_no = array('yes' => 'Yes', 'no' => 'No');

//**********************************************************
// Is Admin?
//**********************************************************
$is_admin = $_SESSION['is_admin'];
define('IS_ADMIN', $is_admin);

//**********************************************************
// Include Local CSS and JavaScript
//**********************************************************
$mod_base_path = __DIR__;
$mod_base_html_path = '/cdn';
foreach ($this->mod_params as $mp_index => $mod_param) {
	$mod_base_path .= "/{$mod_param}";
	$mod_base_html_path .= "/{$mod_param}";

	//-----------------------------------------------------
	// Local CSS
	//-----------------------------------------------------
	$local_css = "{$mod_base_path}/local.css";
	if (file_exists($local_css)) {
		$local_css_url = "{$mod_base_html_path}/local.css";
		$this->add_css_file($local_css_url);
	}

	//-----------------------------------------------------
	// Local JavaScript
	//-----------------------------------------------------
	$local_js = "{$mod_base_path}/local.js";
	if (file_exists($local_js)) {
		$local_js_url = "{$mod_base_html_path}/local.js";
		$this->add_js_file($local_js_url);
	}
}

//**********************************************************
// Debug
//**********************************************************
//$this->set_output_xml();
//print_array($_SESSION);

?>