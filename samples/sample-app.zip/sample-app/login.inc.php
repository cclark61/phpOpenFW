<?php
//=========================================================================
//=========================================================================
// Login Include File
//=========================================================================
//=========================================================================

// THIS IS A BAND-AID (until a future framework update).
include_once("{$_SESSION['frame_path']}/core/data_access/data_query.class.php");
load_plugin("qdba");

//************************************************************
// Protocol
//************************************************************
$protocol = (!empty($_SERVER['HTTPS'])) ? ('https') : ('http');

//************************************************************
// Set default data source
//************************************************************
if (isset($_SESSION['default_data_source'])) {
	default_data_source($_SESSION['default_data_source']);
}

//************************************************************
// Remember Data Sources
//************************************************************
$_SESSION['data_sources'] = array_keys($data_arr);

//************************************************************
// Plugin Folders
//************************************************************
if (isset($_SESSION['add_plugin_folder'])) {
	set_plugin_folder($_SESSION['file_path'] . '/' . $_SESSION['add_plugin_folder']);
}

//************************************************************
// Plugin Folders
//************************************************************
set_plugin_folder('/var/www/html/Library/php/phpOpenPlugins');
set_plugin_folder(dirname(__FILE__) . '/plugins/dios');
if (isset($_SESSION['add_plugin_folder'])) {
	if (is_array($_SESSION['add_plugin_folder'])) {
		foreach ($_SESSION['add_plugin_folder'] as $plugin) {
			set_plugin_folder($_SESSION['file_path'] . '/' . $plugin);		
		}
	}
	else {
		set_plugin_folder($_SESSION['file_path'] . '/' . $_SESSION['add_plugin_folder']);
	}
}

//************************************************************
// Reset User ID to all lowercase
//************************************************************
$_SESSION['userid'] = strtolower($_SESSION['userid']);
$_SESSION['username'] = $_SESSION['userid'];

//************************************************************
// Theme
//************************************************************
if (empty($_SESSION['theme'])) {
	$_SESSION['theme'] = 'default';
}

//************************************************************
// Timezone
//************************************************************
if (empty($_SESSION['time_zone'])) {
	$_SESSION['time_zone'] = "America/New_York";
}

//************************************************************
// Server Side Validation Template
//************************************************************
$_SESSION['ssv_template'] = __DIR__ . '/templates/ssv_messages.xsl';

//************************************************************
// Log this login for this user
//************************************************************
/*
load_plugin('dio');
load_plugin('login_log');
$ll = new login_log();
$ll_data = array();
$ll_data['person_id'] = $_SESSION['person_id'];
$ll_data['userid'] = $_SESSION['userid'];
$ll_data['server_name'] = $_SERVER['SERVER_NAME'];
$ll_data['ip_address'] = $_SERVER['REMOTE_ADDR'];
$ll->import($ll_data);
$ll->save();
*/

//************************************************************
// Redirect
//************************************************************
if (!empty($_SESSION['login_url'])) {
	$red_url = $_SESSION['login_url'];
	unset($_SESSION['login_url']);
	header("Location: {$protocol}://{$red_url}");
}
else {
	header("Location: /");
}
exit;

?>
