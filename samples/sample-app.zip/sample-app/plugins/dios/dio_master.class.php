<?php

class dio_master extends database_interface_object
{

	//------------------------------------------------
	// Log Inserts / Updates
	//------------------------------------------------
	protected function post_save($id=false)
	{
		$record_id = (empty($id)) ? ('') : (json_encode($id));
		$encoded_data = json_encode($this->export());

		$strsql = "
			insert into db_trans_hist (trans_url, trans_type, create_person_id, create_userid, db_table, record_id, json_data)
			values (?, ?, ?, ?, ?, ?, ?)
		";
		$trans_type = (empty($id)) ? ('insert') : ('update');
		$params = [
			'ssissss',
			$_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'],
			$trans_type,
			$_SESSION['person_id'],
			$_SESSION['userid'],
			$this->table,
			$record_id,
			$encoded_data
		];
		qdb_exec('', $strsql, $params);

		return null;
	}

	//------------------------------------------------
	// Log Deletes
	//------------------------------------------------
	protected function post_delete($id)
	{
		$record_id = (empty($id)) ? ('') : (json_encode($id));

		$strsql = "
			insert into db_trans_hist (trans_url, trans_type, create_person_id, create_userid, db_table, record_id, json_data)
			values (?, ?, ?, ?, ?, ?, ?)
		";
		$params = [
			'ssissss',
			$_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'],
			'delete',
			$_SESSION['person_id'],
			$_SESSION['userid'],
			$this->table,
			$record_id,
			''
		];
		qdb_exec('', $strsql, $params);

		return null;
	}
}

?>
