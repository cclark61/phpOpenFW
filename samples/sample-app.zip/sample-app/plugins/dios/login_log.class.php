<?php

class login_log extends database_interface_object
{	
	// Constructor function
	public function __construct()
	{
		$this->set_data_source($_SESSION['default_data_source'], 'login_log');
		$this->set_pkey("id");
		$this->use_bind_params();
	}
}

?>