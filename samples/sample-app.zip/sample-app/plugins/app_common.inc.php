<?php
//*****************************************************************************
//*****************************************************************************
/**
* Application Generic Functions Plugin
*
* @package		Application
* @subpackage	Plugins
**/
//*****************************************************************************
//*****************************************************************************

//*****************************************************************************
//*****************************************************************************
// Load Module Plugin
//*****************************************************************************
//*****************************************************************************
function load_module_plugin($plugin)
{
	$module = $GLOBALS['current_module'];

	$plugin_path = "{$_SESSION['file_path']}/modules";
	if (!empty($module)) { $plugin_path .= '/' . $module; }
	$plugin_path .= "/assets/plugins";

	if (file_exists("{$plugin_path}/{$plugin}.class.php")) {
		include_once("{$plugin_path}/{$plugin}.class.php");
		return true;
	}
	else if (file_exists("{$plugin_path}/{$plugin}.inc.php")) {
		include_once("{$plugin_path}/{$plugin}.inc.php");
		return true;
	}
	else {
		display_error(__FUNCTION__, "Plugin \"{$plugin}\" could not be found.");
	}

	return false;
}

//*****************************************************************************
//*****************************************************************************
// Print a Header
//*****************************************************************************
//*****************************************************************************
function print_header($content)
{
	print xhe('div', icon('fa fa-chevron-right') . ' ' . $content, array('class' => 'well well-sm header_title'));
}

//*****************************************************************************
//*****************************************************************************
// Print a Sub-Header
//*****************************************************************************
//*****************************************************************************
function print_sub_header($content)
{
	print xhe('div', icon('fa fa-caret-right') . ' ' . $content, array('class' => 'well well-sm sub_header_title'));
}

//*****************************************************************************    
/**
* Return a Twitter Bootstrap CSS based Icon
*
* @param string Icon to use i.e. fa fa-check
*
* @return string HTML CSS Icon
*/
//*****************************************************************************    
function icon($i)
{
	if (empty($i)) { return false; }
	return "<i class=\"{$i}\"></i>";
}

?>