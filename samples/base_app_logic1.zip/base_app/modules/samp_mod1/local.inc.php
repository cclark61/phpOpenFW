<?php

$mod_title = "Sample Module #1";

?>