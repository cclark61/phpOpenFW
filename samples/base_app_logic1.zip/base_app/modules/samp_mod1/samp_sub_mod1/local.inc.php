<?php

$mod_title = "Sample Sub Module #1";

?>