<?php

switch ($this->action) {

	default:
		include('main.php');
		break;
}

?>
