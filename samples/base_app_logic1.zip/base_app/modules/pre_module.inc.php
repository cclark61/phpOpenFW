<?php
//=========================================================================
// Pre-module execution include file
//=========================================================================

//$this->set_output_xml();
//print_array($_SESSION);

//**************************************************
// Set Current Date
//**************************************************
$this->add_xml("current_date", date('l, M j, Y'));

//**************************************************
// Message Arrays
//**************************************************
$error_message = array();
$warn_message = array();
$action_message = array();
$gen_message = array();

//**************************************************
// Nav Arrays
//**************************************************
$top_mod_links = array();
$breadcrumbs = array();

//**********************************************************
// Images
//**********************************************************
$icon_base_dir = "$this->html_path/img/icons";
$add_image = image("$icon_base_dir/add.png", "[+]", array("title" => "add", "class" => "gen_icon"));
$edit_image = image("$icon_base_dir/edit.png", "[edit]", array("title" => "edit", "class" => "gen_icon"));
$open_image = image("$icon_base_dir/folder_go.png", "[open]", array("title" => "open", "class" => "gen_icon"));
$delete_image = image("$icon_base_dir/cross.png", "[delete]", array("title" => "delete", "class" => "gen_icon"));
$view_image = image("$icon_base_dir/view.png", "[view]", array("title" => "view", "class" => "gen_icon"));
$check_image = image("$icon_base_dir/tick.png", "[x]", array("title" => "Complete", "class" => "gen_icon"));
$cancel_image = image("$icon_base_dir/cancel.png", "[--]", array("title" => "--", "class" => "gen_icon"));
$filter_image = image("$icon_base_dir/table.png", "[&raquo;]", array("title" => "Filter / Sort", "class" => "gen_icon"));
$action_image = image("$icon_base_dir/action.png", "[&raquo]", array("title" => "action", "class" => "gen_icon"));
$cat_image = image("$icon_base_dir/categories.png", "[&raquo]", array("title" => "list", "class" => "gen_icon"));
$notes_image = image("$icon_base_dir/note.png", "[&raquo;]", array("title" => "notes", "class" => "gen_icon"));
$arrowr_image = image("$icon_base_dir/bullet_go.png", "[&raquo;]", array("title" => "&raquo;", "class" => "gen_icon"));
$arrowl_image = image("$icon_base_dir/bullet_go_back.png", "[&laquo;]", array("title" => "&laquo;", "class" => "gen_icon"));
$info_image = image("$icon_base_dir/information.png", "[!]", array("title" => "information", "class" => "gen_icon"));
$site_image = image("$icon_base_dir/layout.png", "[&raquo;]", array("title" => "Site", "class" => "gen_icon"));
$content_image = image("$icon_base_dir/page_edit.png", "[&raquo;]", array("title" => "Content", "class" => "gen_icon"));
$entries_image = image("$icon_base_dir/categories.png", "[&raquo]", array("title" => "entries", "class" => "gen_icon"));
$folder_image = image("$icon_base_dir/folder.png", "[&raquo]", array("title" => "folder", "class" => "gen_icon"));
$cont_ent_image = image("$icon_base_dir/page.png", "[&raquo]", array("title" => "entry", "class" => "gen_icon"));
$active_image = image("$icon_base_dir/bullet_green.png", "[Active]", array("title" => "active", "class" => "gen_icon"));
$disabled_image = image("$icon_base_dir/bullet_red.png", "[Disabled]", array("title" => "disabled", "class" => "gen_icon"));

//**************************************************
// Default Module Image
//**************************************************
$mod_image = image("$icon_base_dir/brick.png", "[~]", array("title" => "Module", "class" => "gen_icon"));

//**********************************************************
// Set Action / Next action
//**********************************************************
$next_action = array("add" => "insert", "edit" => "update", "confirm_delete" => "delete");

?>
