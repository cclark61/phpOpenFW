<?php
//=========================================================================
//=========================================================================
// Post-module execution include file
//=========================================================================
//=========================================================================

//**************************************************************
// Module Title
//**************************************************************
if (!isset($mod_title)) { $mod_title = "???"; }
$this->add_xml("mod_title", xml_escape($mod_title));

//**************************************************************
// Sub Title / Back Link
//**************************************************************
if (isset($sub_title)) { $this->add_xml("sub_title", xml_escape($sub_title)); }
if (isset($back_link)) { $this->add_xml("back_link", xml_escape($back_link)); }

//**************************************************************
// Module Image
//**************************************************************
if (isset($mod_image)) { $this->add_xml("mod_image", xml_escape($mod_image)); }

//**************************************************************
// Links
//**************************************************************
if (isset($top_mod_links) && is_array($top_mod_links) && count($top_mod_links) > 0) { $this->add_xml("top_mod_links", $top_mod_links); }

//**************************************************************
// Breadcrumbs
//**************************************************************
if (isset($breadcrumbs) && is_array($breadcrumbs) && count($breadcrumbs) > 0) { $this->add_xml("breadcrumbs", $breadcrumbs); }

//**************************************************************
// Convert Message strings into arrays
//**************************************************************
if (isset($error_message) && !is_array($error_message)) { $error_message = array($error_message); }
if (isset($warn_message) && !is_array($warn_message)) { $warn_message = array($warn_message); }
if (isset($action_message) && !is_array($action_message)) { $action_message = array($action_message); }
if (isset($gen_message) && !is_array($gen_message)) { $gen_message = array($gen_message); }

//**************************************************************
// Page Checks (Post Page)
//**************************************************************
$pre_post_mod = dirname(__FILE__) . "/pre_post_module.inc.php";
if (file_exists($pre_post_mod)) { include($pre_post_mod); }

//**************************************************************
// Messages
//**************************************************************
if (isset($error_message) && count($error_message) > 0) { $this->add_xml("error_message", array2xml("error_messages", $error_message)); }
if (isset($warn_message) && count($warn_message) > 0) { $this->add_xml("warn_message", array2xml("warn_messages", $warn_message)); }
if (isset($action_message) && count($action_message) > 0) { $this->add_xml("action_message", array2xml("action_messages", $action_message)); }
if (isset($gen_message) && count($gen_message) > 0) { $this->add_xml("gen_message", array2xml("gen_messages", $gen_message)); }

//**************************************************************
//**************************************************************
// Format Page Messages function
//**************************************************************
//**************************************************************
function format_page_messages($messages)
{
	if (is_array($messages) && count($messages) > 0) {
		foreach ($messages as $key => $message) {
			$messages[$key] = xml_escape($message);
		}
		return $messages;
	}
	else if ($messages && $messages != "") {
		return array(xml_escape($messages));
	}
	else {
		return false;
	}
}

?>
