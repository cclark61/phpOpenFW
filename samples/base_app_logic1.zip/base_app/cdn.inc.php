<?php

/**
* Content Devlivery Controller
*
* @package		Controller
* @subpackage	Content Devlivery
* @author 		Christian J. Clark
* @version 		Started: 12/6/2011, Last updated: 12/6/2011
**/

//****************************************************
// "Pseudo" Content Devlivery Network
//****************************************************
$path_info = (isset($_SERVER['PATH_INFO'])) ? ($_SERVER['PATH_INFO']) : (false);
if ($path_info && substr($path_info, 0, 5) == '/cdn/') {
	$cdn_file = dirname(__FILE__) . substr($path_info, 4);
	if (file_exists($cdn_file) && !is_dir($cdn_file)) {
		$file_info = pathinfo($cdn_file);

		switch (strtolower($file_info['extension'])) {

			// Javascript
			case 'js':
				header('Content-type: text/javascript');
				break;

			// CSS
			case 'css':
				header('Content-type: text/css');
				break;

			// Images
			case 'jpg':
			case 'gif':
			case 'png':
				header("Content-type: image/{$file_info['extension']}");
				break;

			// XML
			case 'xml':
				header('Content-type: text/xml');
				break;

			// Default
			default:
				header('Content-type: text/text');
				break;
		}

		print file_get_contents($cdn_file);
	}
	else {
		header("HTTP/1.0 404 Not Found");
	}
	exit;
}
define('CDN_BASE', $_SERVER['PHP_SELF'] . '/cdn');

?>
