<?php
//********************************************************************
//********************************************************************
// Site Configuration
//********************************************************************
//********************************************************************

//*********************************************************
// phpOpenFW Framework Path
//*********************************************************
$config['site_lib'] = '/var/www/html/Library/php';
$config['framework_path'] = $config['site_lib'] . '/phpOpenFW1/framework';

//*********************************************************
// Detect Site Mode
//*********************************************************
$server_name = $_SERVER['SERVER_NAME'];
$config['server_name'] = $server_name;
switch ($server_name) {

	case 'www.example.com':
		$mode = 'live';
		break;

	default:
		$mode = 'dev';
		break;
}

//********************************************************************
// Set mode in configuration
//********************************************************************
$config['mode'] = $mode;

//********************************************************************
// Cache Directory
//********************************************************************
$config['cache_dir'] = realpath(__DIR__ . '/../content/www/cache');

//********************************************************************
// Mode Dependent Site Settings
//********************************************************************
switch ($mode) {

	//***********************************
	// Live
	//***********************************
	case 'live':
		$config['buffer_page'] = 1;
		$config['catch_errors'] = 1;
		break;

	//***********************************
	// Development
	//***********************************
	case 'dev':
		$config['buffer_page'] = 0;
		$config['catch_errors'] = 0;
		break;

}

//********************************************************************
// Data Source Configuration
//********************************************************************
switch ($mode) {

	//***********************************
	// Development
	//***********************************
	case 'dev':

		$i = "main";
		$data_arr[$i]["type"] = "mysqli";
		$data_arr[$i]["port"] = 3306;
		$data_arr[$i]["source"] = "example_db_dev";
		$data_arr[$i]["server"] = "127.0.0.1";
		$data_arr[$i]["user"] = "user";
		$data_arr[$i]["pass"] = "pass";

		break;

	//***********************************
	// Live
	//***********************************
	case 'live':

		$i = "main";
		$data_arr[$i]["type"] = "mysqli";
		$data_arr[$i]["port"] = 3306;
		$data_arr[$i]["source"] = "example_db_live";
		$data_arr[$i]["server"] = "127.0.0.1";
		$data_arr[$i]["user"] = "user";
		$data_arr[$i]["pass"] = "pass";

		break;

}

?>