<?php
//*************************************************************
//*************************************************************
// Pre-page Include File
//*************************************************************
//*************************************************************

//*********************************************************
// HTTPS / Protocol Constants
//*********************************************************
if (!defined('HTTPS')) { define('HTTPS', $https); }
$site_protocol = (HTTPS) ? ('https') : ('http');
if (!defined('SITE_PROTOCOL')) { define('SITE_PROTOCOL', $site_protocol); }

//*********************************************************
// Set Timezone
//*********************************************************
date_default_timezone_set('America/New_York');

//********************************************************************
// Defined Constatnts
//********************************************************************
define('SITE_LIB', $site_lib);

//********************************************************************
// Mode Independent Site Settings
//********************************************************************

//---------------------------------------------------------
// Reset default Page Layout 'page' to 'page_1col'
//---------------------------------------------------------
$content_layout = 'page_default';

//---------------------------------------------------------
// Default Page Title
//---------------------------------------------------------
$page->set_data('title', 'Sample Site');

//---------------------------------------------------------
// Footer Text
//---------------------------------------------------------
$page->set_data('copyright', date('Y') . ' Your Company. All Rights Reserved.');

//*********************************************************
// Referring URLs
//*********************************************************
$abs_ref_url = (!empty($_SERVER['HTTP_REFERER'])) ? ($_SERVER['HTTP_REFERER']) : (false);
define('ABS_REF_URL', $abs_ref_url);
$rel_ref_url = ($abs_ref_url) ? (str_replace("{$site_protocol}://{$server_name}", '', $abs_ref_url)) : (false);
define('REL_REF_URL', $rel_ref_url);
$external_ref = ($rel_ref_url && stripos($rel_ref_url, $site_protocol) !== false) ? (true) : (false);
define('EXTERNAL_REFERRER', $external_ref);

//*********************************************************
// Set HTML Paths
//*********************************************************
$img_dir = '/img';
$page->set_data('img_dir', $img_dir);
$icon_dir = $img_dir . '/icons';
$page->set_data('icon_dir', $icon_dir);

//*********************************************************
// Load Common Plugins
//*********************************************************
load_plugin('content_gen');
load_plugin('xhtml_gen');
load_plugin('date_time');

//*********************************************************
// phpOpenPlugins
//*********************************************************
$pop = SITE_LIB . "/phpOpenPlugins";
if (is_dir($pop)) {
	set_plugin_folder($pop);
	load_plugin('website_gen_functions');
}

//*********************************************************
// Main Nav
//*********************************************************
$page->set_data('main_nav', load_file_content($nav_dir, '/main_nav.xml'));
$page->no_escape_element('main_nav');

//*********************************************************
// Current Page URL
//*********************************************************
$page->set_data('curr_page_url', $_SERVER['REQUEST_URI']);

?>