<?php

//==============================================================
// Set Content Layout
//==============================================================
$content_layout = 'default_page';

//==============================================================
// Set Content Data
//==============================================================
$tmp_content = array(
	'title' => 'Contact Page',
	'content_header' => 'Contact',
	'content' => 'Contact...',
	'content_layout' => $content_layout
);

//==============================================================
// Include Page Layout Structure
//==============================================================
include("{$base_path}/page_layouts/{$content_layout}.inc.php");

?>