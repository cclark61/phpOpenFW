<?php
//*********************************************************************
//*********************************************************************
// Default Page Layout
//*********************************************************************
//*********************************************************************
if ($throw_404 || $throw_500) { return false; }

//==============================================================
// Set Content Layout
//==============================================================
$content_layout = 'page_default';

//==============================================================
// Content was found
//==============================================================
if (isset($tmp_content['content']) && $tmp_content['content'] !== false) {
	if (!empty($tmp_content['content_header'])) {
		$page->set_data('content_header', $tmp_content['content_header']);
	}
	if (!empty($tmp_content['title'])) {
		$page->set_data('title', ' - ' . $tmp_content['content_header'], true);
	}
	if (!empty($tmp_content['content'])) {
		$page->set_data('content', $tmp_content['content']);
	}
	if (!empty($tmp_content['content_layout'])) {
		$page->set_data('content_layout', $content_layout);
	}
}
//==============================================================
// Content was NOT found or Error, Throw 404 like page
//==============================================================
else {
	$throw_404 = true;
}

?>