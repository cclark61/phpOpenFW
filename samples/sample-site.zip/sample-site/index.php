<?php

/**
* Site Main Controller
*
* This controller assumes you are using a catch-all rule with mod_rewrite for Apache 
* or using a long URL format.
*
* @package		Main Controller
* @subpackage	Controller
* @author 		Christian J. Clark
* @version 		Started: 10/20/2010, Last updated: 2/18/2013
**/

//**************************************************************************************
//**************************************************************************************
// Main Application Controller
//**************************************************************************************
//**************************************************************************************

//*************************************************
// Start the session
//*************************************************
session_start();

//*************************************************
// Load the configuration if necessary
//*************************************************
if (!isset($_SESSION['config'])) {
	$config = array();
	$config['file_path'] = dirname(__FILE__);
	$config_file = __DIR__ . '/config.inc.php';

	if (!file_exists($config_file)) {
		die('Error: Configuration file not found!');
	}
	else {
		include($config_file);
		if (!empty($config) && is_array($config) && $config > 1) {
			extract($config);
			$_SESSION['config'] = $config;
		}
		else {
			die('Error: Site configuration is empty or invalid!');
		}
	}
}
else {
	extract($_SESSION['config']);
}

//*************************************************
// Include Main Controller
//*************************************************
if (isset($framework_path) && is_dir($framework_path)) {
	include("{$framework_path}/site_controller.php");
}
else {
	die('Error: Framework path is not set or is invalid!');
}

?>
