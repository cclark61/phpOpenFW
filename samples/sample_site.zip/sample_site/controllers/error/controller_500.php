<?php

//**********************************************************
// Set Content Layout
//**********************************************************
$content_layout = 'page_1col';
 
//**********************************************************
// Error Page Content
//**********************************************************
if (!isset($msg_500)) {
	$msg_500 = 'Sorry! There was an error on this page.';
}
if (!isset($title_500)) {
	$title_500 = 'Page Error';
}
if (!isset($header_500)) {
	$header_500 = 'Page Error';
}

//**********************************************************
// Set Page Data
//**********************************************************
$page->set_data('title', " - {$title_500}", true);
$page->set_data('content_header', $header_500);
$page->set_data('content', $msg_500);

?>
