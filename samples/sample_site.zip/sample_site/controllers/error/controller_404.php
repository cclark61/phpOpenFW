<?php

//**********************************************************
// Set Content Layout
//**********************************************************
$content_layout = 'page_1col';
 
//**********************************************************
// Error Page Content
//**********************************************************
if (!isset($msg_404)) {
	$msg_404 = 'The page you are looking for cannot be found.';
}
if (!isset($title_404)) {
	$title_404 = 'Page Not Found';
}
if (!isset($header_404)) {
	$header_404 = 'Page Not Found';
}

//**********************************************************
// Set Page Data
//**********************************************************
$page->set_data('title', " - {$title_404}", true);
$page->set_data('content_header', $header_404);
$page->set_data('content', $msg_404);

?>
