<?php

if (!isset($curr_page2)) {
	$site_args['keytag'] = $curr_page1;

	// Include Page Layout Structure
	include($base_path . '/page_layouts/std_1col.inc.php');
}
else { $throw_404 = true; }

?>
