<?php

//*************************************************************
// Page Parameters
//*************************************************************
$site_args['keytag'] = $curr_page1;
$url_stub = SITE_HOME_URL . '/' . $curr_page1;
$page->set_data('content_header', 'Item 1');
$page->set_data('page_rss_feed', $url_stub . '/feed/');

// Secondary Nav
$page->set_data("secondary_nav", load_file_content($nav_dir, "/item1.xml"));

//*************************************************************
// Include Controller
//*************************************************************
include($base_path . '/page_layouts/std_1col.inc.php');

?>
