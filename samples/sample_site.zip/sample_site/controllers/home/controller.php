<?php

ob_start();
include('main.php');
$page->set_data('content', ob_get_clean());

?>
