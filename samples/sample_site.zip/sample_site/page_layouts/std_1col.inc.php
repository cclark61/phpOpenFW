<?php
//*********************************************************************
//*********************************************************************
// Standard 1 Column Layout
//*********************************************************************
//*********************************************************************

// Set Content Layout
$content_layout = 'page_1col';

// Attempt to Pull Content
$tmp_content = LWCMS_DC::get_content_by_keytag($site_args);

if (isset($tmp_content['content']) && $tmp_content['content'] !== false) {
	$page->set_data('content_header', $tmp_content['entry_title']);
	$page->set_data('title', ' - ' . $tmp_content['entry_title'], true);
	$page->set_data('content', $tmp_content['content']);
}
else {
	// Content not found or Error, Throw 404 like page	
	$throw_404 = true;
}

?>
