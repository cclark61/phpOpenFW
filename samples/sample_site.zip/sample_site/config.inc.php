<?php
//********************************************************************
//********************************************************************
// Site Configuration
//********************************************************************
//********************************************************************

//*********************************************************
// phpOpenFW Framework Path
//*********************************************************
$config['framework_path'] = '/var/www/html/Library/php/phpOpenFW1/framework';
$config['site_lib'] = dirname(__FILE__) . '/lib';
$config['pop_dir'] = '/var/www/html/Library/php/phpOpenPlugins';

//*********************************************************
// Detect Site Mode
//*********************************************************
$server_name = $_SERVER['SERVER_NAME'];
$config['server_name'] = $server_name;
switch ($server_name) {
	case 'www.example.com':
	case 'example.com':
		$mode = 'live';
		break;

	case 'www.test.example.com':
		$mode = 'test';
		break;

	case 'www.dev.example.com':
		$mode = 'dev';
		break;

//	default:
//		header('Location: http://www.dev.example.com');
//		exit;
//		break;

	default:
		$mode = 'dev';
		break;
}

// Set mode in configuration
$config['mode'] = $mode;

//********************************************************************
// Mode Dependent Site Settings
//********************************************************************
switch ($mode) {

	//***********************************
	// Live
	//***********************************
	case 'live':
		$config['site_id'] = 1;
		$config['blog_id'] = 0;
		$config['content_mode'] = 2;
		$config['cache_dir'] = '/var/www/html/example.com/content/www/dynamic_content';
		$config['buffer_page'] = 1;
		$config['catch_errors'] = 1;
		$config['page_logging'] = 1;
		break;

	//***********************************
	// Test
	//***********************************
	case 'test':
		$config['site_id'] = 1;
		$config['blog_id'] = 0;
		$config['content_mode'] = 1;
		$config['cache_dir'] = '/var/www/html/example.com/content/www/dynamic_content';
		$config['buffer_page'] = 0;
		$config['catch_errors'] = 1;
		$config['page_logging'] = 1;
		break;

	//***********************************
	// Development
	//***********************************
	case 'dev':
		$config['site_id'] = 1;
		$config['blog_id'] = 0;
		$config['content_mode'] = 0;
		$config['cache_dir'] = '/var/www/html/example.com/content/www/dynamic_content';
		$config['buffer_page'] = 0;
		$config['catch_errors'] = 0;
		$config['page_logging'] = 0;
		break;

}

//********************************************************************
// Data Source Configuration
//********************************************************************
switch ($mode) {

	//***********************************
	// Development
	//***********************************
	case 'dev':

		$i = "main";
		$data_arr[$i]["type"] = "mysqli";
		$data_arr[$i]["port"] = 3306;
		$data_arr[$i]["source"] = "example_dev";
		$data_arr[$i]["server"] = "db.example.com";
		$data_arr[$i]["user"] = "dev_user";
		$data_arr[$i]["pass"] = "dev_pass";
		
		$i = "lwcms";
		$data_arr[$i]["type"] = "mysqli";
		$data_arr[$i]["port"] = 3306;
		$data_arr[$i]["source"] = "lwcms_example_dev";
		$data_arr[$i]["server"] = "db.example.com";
		$data_arr[$i]["user"] = "dev_user";
		$data_arr[$i]["pass"] = "dev_pass";

		break;

	//***********************************
	// Test
	//***********************************
	case 'test':

		$i = "main";
		$data_arr[$i]["type"] = "mysqli";
		$data_arr[$i]["port"] = 3306;
		$data_arr[$i]["source"] = "example_test";
		$data_arr[$i]["server"] = "db.example.com";
		$data_arr[$i]["user"] = "dev_user";
		$data_arr[$i]["pass"] = "dev_pass";
		
		$i = "lwcms";
		$data_arr[$i]["type"] = "mysqli";
		$data_arr[$i]["port"] = 3306;
		$data_arr[$i]["source"] = "lwcms_example_test";
		$data_arr[$i]["server"] = "db.example.com";
		$data_arr[$i]["user"] = "dev_user";
		$data_arr[$i]["pass"] = "dev_pass";

		break;

	//***********************************
	// Live
	//***********************************
	case 'live':

		$i = "main";
		$data_arr[$i]["type"] = "mysqli";
		$data_arr[$i]["port"] = 3306;
		$data_arr[$i]["source"] = "example_live";
		$data_arr[$i]["server"] = "db.example.com";
		$data_arr[$i]["user"] = "dev_user";
		$data_arr[$i]["pass"] = "dev_pass";
		
		$i = "lwcms";
		$data_arr[$i]["type"] = "mysqli";
		$data_arr[$i]["port"] = 3306;
		$data_arr[$i]["source"] = "lwcms_example_live";
		$data_arr[$i]["server"] = "db.example.com";
		$data_arr[$i]["user"] = "dev_user";
		$data_arr[$i]["pass"] = "dev_pass";

		break;

}
?>
