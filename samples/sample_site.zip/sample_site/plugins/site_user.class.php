<?php

class site_user extends database_interface_object
{	
	// Constructor function
	public function __construct()
	{
		$this->set_data_source("main", "users");
		$this->set_pkey("id");
	}
}

?>