<?php
//*************************************************************
//*************************************************************
// Post-page Include File
//*************************************************************
//*************************************************************

//*************************************************************
// Page Logging Enabled?
//*************************************************************
if (empty($page_logging)) { return false; }

//*************************************************************
// Compute page load time
//*************************************************************
list($usec, $sec) = explode(" ", $page_start_time);
$tmp1 = ((float)$usec + (float)$sec);
list($usec, $sec) = explode(" ", $page_end_time);
$tmp2 = ((float)$usec + (float)$sec);
$load_time = round($tmp2 - $tmp1, 4);

//*************************************************************
// Log page hit to database
//*************************************************************
$session_id = session_id();
if (!isset($action_status)) { $action_status = 0; }
$ip_addr = (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) ? ($_SERVER['HTTP_X_FORWARDED_FOR']) : ($_SERVER['REMOTE_ADDR']);
$page_url = ($_SERVER['REQUEST_URI']) ? ($_SERVER['REQUEST_URI']) : ('??');

$strsql = "
	insert into page_hits (site_url, ip_addr, session_id, load_time, page_url, page_status, action_status)
	values (?, ?, ?, ?, ?, ?, ?)
";

$params = array(
	'sssdsii',
	$server_name,
	$ip_addr,
	$session_id,
	$load_time,
	$page_url,
	$page_status,
	$action_status
);
$page_hit_id = qdb_exec('main', $strsql, $params);

//*************************************************************
// Log Page Errors
//*************************************************************
if (isset($_SESSION['page_errors'])) {
	foreach ($_SESSION['page_errors'] as $err) {
		extract($err);
		$errstr = addslashes($errstr);
		$errfile = addslashes($errfile);
	
		$strsql = "
			insert into page_errors (page_hit_id, errno, errstr, errfile, errline)
			values (?, ?, ?, ?, ?)
		";
		$params = array(
			'iissi',
			$page_hit_id,
			$errno,
			$errstr,
			$errfile,
			$errline
		);
		qdb_exec('main', $strsql, $params);
	}
	unset($_SESSION['page_errors']);
}


?>
